name 'hadoop'
maintainer 'Tuto'
maintainer_email 'tuto@sloopstash.com'
license 'Apache License 2.0'
description 'A cookbook to deploy Hadoop.'
long_description 'A cookbook to deploy Hadoop.'
version '1.1.1'
chef_version '>= 12' if respond_to?(:chef_version)
