## Hadoop Cookbook
A cookbook to deploy Hadoop.
