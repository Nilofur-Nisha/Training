/usr/local/lib/hadoop/sbin/start-dfs.sh
/usr/local/lib/hadoop/sbin/start-yarn.sh