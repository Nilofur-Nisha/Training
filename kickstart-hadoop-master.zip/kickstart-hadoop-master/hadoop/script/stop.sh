/usr/local/lib/hadoop/sbin/stop-dfs.sh
/usr/local/lib/hadoop/sbin/stop-yarn.sh