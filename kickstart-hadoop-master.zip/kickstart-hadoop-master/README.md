# Kickstart Hadoop
The ultimate aim of this Hadoop starter-kit Git repository is to help you deploy and manage Hadoop ecosystem components on Docker containers and AWS cloud. You need user manual to operate the starter-kit. Contact us to get the user manual and start learning Hadoop today.
